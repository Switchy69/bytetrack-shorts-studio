@echo off
setlocal
cd /d "%~dp0"
py shorts_studio.py
if errorlevel 1 (
  echo.
  echo The app exited with an error. Try running install_requirements.bat first.
  pause
)
