BYTETALK SHORTS STUDIO - WINDOWS SETUP
======================================

WHAT IT DOES
------------
- Checks the ByteTalkYT Shorts tab (URL is editable in the app).
- Scans recent entries and finds up to 5 videos not in processed_history.txt.
- Downloads source Shorts and saves transcript/script text files.
- Uses YouTube captions when available; otherwise, transcribes with faster-whisper.
- Generates a neural AI voiceover and timed captions.
- Crops an upper panel from the source Short based on the example screenshot.
- Places that panel over a randomly selected local Minecraft gameplay background.
- Exports an MP4 to the finished folder by default.
- Can auto-check for new Shorts while the app remains open.
- Includes an over-the-air (OTA) updater that polls the configured HTTPS manifest every
  30 seconds, shows a bottom-right always-on-top progress popup, verifies SHA-256, pauses
  between Shorts, installs the update, and restarts the app automatically.

NORMAL SETUP
------------
1. Install Python 3.10+ from https://www.python.org/downloads/ and enable "Add Python to PATH".
2. Double-click install_requirements.bat and wait for it to finish.
3. Put Minecraft gameplay clips you own or are licensed to use in minecraft_backgrounds.
4. Double-click run_app.bat.
5. Click "Check channel now". For recurring scans, click "Start auto-check".
6. Finished videos are saved in the finished folder by default.

OVER-THE-AIR CODE UPDATES - ONE-TIME HOSTING SETUP
-------------------------------------------------
The updater code is built into this app, but this ZIP does NOT include a live public server.
A hosted HTTPS update manifest is required before your PC can receive remote code changes.
The included setup uses GitHub Releases for the ZIP package and a public raw GitHub URL for
latest.json. Do not put passwords, API tokens, or private account data in the update feed.

A. Create a PUBLIC GitHub repository to host the update feed. This app is configured for:
   https://github.com/Switchy69/bytetrack-shorts-studio
   The repository must be public so the app can read latest.json without credentials.

B. For a release, open build_update_release.bat and enter the version, owner, and repo.
   For the current popup/polling updater release, use:
   Version: 1.0.2
   GitHub username/organization: Switchy69
   Repository: bytetrack-shorts-studio
   It creates release_build/bytetrack-shorts-studio-v1.0.2.zip and release_build/latest.json.

C. On GitHub, create a Release tagged v1.0.2 and upload the generated ZIP as a release asset.
   Then upload release_build/latest.json into the root of this public repository's main branch
   with the filename latest.json. The download URL in that manifest must match the uploaded
   Release asset exactly.

D. On an existing install, click "Set update feed" and paste this URL once:
   https://raw.githubusercontent.com/Switchy69/bytetrack-shorts-studio/main/latest.json
   New installations already use this URL by default. The app checks at launch and every
   30 seconds while running. If an update appears, a corner popup shows progress. The app
   finishes only the current Short, pauses the remaining queue, installs, and restarts.

FUTURE UPDATE WORKFLOW
----------------------
1. Ask for the UI or code change and update the app source.
2. Increase APP_VERSION in app_update.py, for example from 1.0.1 to 1.0.2.
3. Run build_update_release.bat with the new version, username/organization, and repository.
4. Edit the changelog in the generated release_build/latest.json.
5. Create a GitHub Release tagged v1.0.2 and upload its ZIP asset.
6. Replace latest.json in the repository's main branch with the generated latest.json.
   Running installs will detect the higher version, ask before download, verify the SHA-256,
   ask before installing, then restart the app.

The updater verifies the downloaded ZIP against the SHA-256 in latest.json, requires HTTPS,
rejects unsafe archive paths, and keeps the user's update_config.json, workspace, finished
videos, Minecraft backgrounds, and update staging/backups outside the app-code replacement.
Only accept updates from a release feed you trust. The checksum protects against corruption;
it is not a digital signature independent of the hosting account. Secure the GitHub account
with strong authentication and do not publish a feed URL from an untrusted source.
The 30-second check is polling rather than an instantaneous server push; GitHub does not need
to send a persistent notification to the app. Your app must remain open and online.

FIRST RUN / TRANSCRIPTION
-------------------------
The first transcription fallback may download the faster-whisper "base" speech model. AI voice
generation needs an internet connection. For automatic Shorts checks, the app must remain open
and the PC must stay awake.

CROP SETTINGS
-------------
The crop is configured in shorts_studio.py inside build_final_video():
  width: 70% of source video width
  height: 30% of source video height
  x offset: 8% from the left
  y offset: 4% from the top
This approximates the circled panel in the supplied example. If the source layout changes,
those percentages may need adjustment.

IMPORTANT
---------
Use this workflow only for source material and background footage that you own, have permission
to reuse, or are otherwise legally entitled to process. The app does not upload or publish videos.
