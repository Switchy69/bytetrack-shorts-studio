from __future__ import annotations

import hashlib
import json
import re
import shutil
import urllib.error
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath
from typing import Callable

APP_VERSION = "1.0.2"
CONFIG_NAME = "update_config.json"
MAX_DOWNLOAD_BYTES = 300 * 1024 * 1024
MAX_UNPACKED_BYTES = 700 * 1024 * 1024
MAX_FILES = 5000
USER_AGENT = f"ByteTalkShortsStudio/{APP_VERSION} (Windows updater)"


def default_config() -> dict:
    return {
        "manifest_url": "https://raw.githubusercontent.com/Switchy69/bytetrack-shorts-studio/main/latest.json",
        "auto_check_on_start": True,
    }


def load_config(app_dir: Path) -> dict:
    """Read local updater settings, creating an example config on first run."""
    path = app_dir / CONFIG_NAME
    if not path.exists():
        path.write_text(json.dumps(default_config(), indent=2) + "\n", encoding="utf-8")
        return default_config()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return default_config()
    if not isinstance(data, dict):
        return default_config()
    default = default_config()
    default.update(data)
    return default


def save_config(app_dir: Path, data: dict) -> None:
    path = app_dir / CONFIG_NAME
    current = load_config(app_dir)
    current.update(data)
    path.write_text(json.dumps(current, indent=2) + "\n", encoding="utf-8")


def is_configured_manifest_url(url: str) -> bool:
    url = str(url or "").strip()
    return (
        url.startswith("https://")
        and "YOUR_GITHUB_USERNAME" not in url
        and "YOUR_REPO" not in url
        and "example.com" not in url
    )


def version_key(version: str) -> tuple[int, ...]:
    match = re.match(r"^\s*v?(\d+(?:\.\d+)*)", str(version))
    if not match:
        raise ValueError(f"Invalid version value: {version!r}")
    return tuple(int(part) for part in match.group(1).split("."))


def is_newer(remote_version: str, current_version: str = APP_VERSION) -> bool:
    remote = version_key(remote_version)
    current = version_key(current_version)
    width = max(len(remote), len(current))
    remote += (0,) * (width - len(remote))
    current += (0,) * (width - len(current))
    return remote > current


def _https_request(url: str, timeout: int = 15) -> urllib.request.Request:
    if not isinstance(url, str) or not url.startswith("https://"):
        raise ValueError("Update URLs must use HTTPS.")
    return urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json, application/zip, */*"})


def fetch_manifest(url: str) -> dict:
    """Fetch and validate a latest.json release manifest."""
    with urllib.request.urlopen(_https_request(url), timeout=15) as response:
        if not response.geturl().startswith("https://"):
            raise RuntimeError("The update manifest redirected away from HTTPS; refusing the connection.")
        body = response.read(1024 * 1024 + 1)
    if len(body) > 1024 * 1024:
        raise RuntimeError("The update manifest is unexpectedly large.")
    try:
        manifest = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeError("The update server returned invalid JSON.") from exc
    if not isinstance(manifest, dict):
        raise RuntimeError("The update manifest must be a JSON object.")

    version = manifest.get("version")
    download_url = manifest.get("download_url")
    checksum = str(manifest.get("sha256", "")).lower()
    if not isinstance(version, str):
        raise RuntimeError("Update manifest is missing a string 'version'.")
    version_key(version)
    if not isinstance(download_url, str) or not download_url.startswith("https://"):
        raise RuntimeError("Update manifest must provide an HTTPS 'download_url'.")
    if not re.fullmatch(r"[0-9a-f]{64}", checksum):
        raise RuntimeError("Update manifest is missing a valid 64-character SHA-256 checksum.")
    manifest["sha256"] = checksum
    manifest["changelog"] = str(manifest.get("changelog", "General improvements and fixes."))[:5000]
    return manifest


def _safe_member_path(root: Path, archive_name: str) -> Path:
    # ZIP paths are POSIX-style by specification, but reject backslashes too to
    # avoid archive entries that become traversal paths on Windows.
    if "\\" in archive_name or "\x00" in archive_name:
        raise RuntimeError(f"Unsafe path in update package: {archive_name!r}")
    member = PurePosixPath(archive_name)
    if member.is_absolute() or not member.parts or any(part in ("..", "") for part in member.parts):
        raise RuntimeError(f"Unsafe path in update package: {archive_name!r}")
    if re.match(r"^[A-Za-z]:", archive_name):
        raise RuntimeError(f"Unsafe drive path in update package: {archive_name!r}")
    destination = (root / Path(*member.parts)).resolve()
    try:
        destination.relative_to(root.resolve())
    except ValueError as exc:
        raise RuntimeError(f"Update package path escapes staging directory: {archive_name!r}") from exc
    return destination


def download_and_stage(
    manifest: dict,
    app_dir: Path,
    progress_callback: Callable[[str, float], None] | None = None,
) -> Path:
    """Download, SHA-256 verify, and safely unpack a release without installing it.

    progress_callback receives (human-readable status, percent 0..100).
    """
    def report(status: str, percent: float) -> None:
        if progress_callback is not None:
            try:
                progress_callback(status, max(0.0, min(100.0, float(percent))))
            except Exception:
                pass

    report("Preparing secure download…", 0)
    version = str(manifest["version"])
    stage_root = app_dir / ".updates" / f"stage_{re.sub(r'[^A-Za-z0-9._-]', '_', version)}"
    if stage_root.exists():
        shutil.rmtree(stage_root)
    stage_root.mkdir(parents=True, exist_ok=True)
    archive_path = stage_root / "update.zip"
    extract_root = stage_root / "payload"
    extract_root.mkdir()

    digest = hashlib.sha256()
    total = 0
    try:
        with urllib.request.urlopen(_https_request(manifest["download_url"]), timeout=30) as response:
            if not response.geturl().startswith("https://"):
                raise RuntimeError("The update package redirected away from HTTPS; refusing the connection.")
            try:
                content_length = int(response.headers.get("Content-Length", "0"))
            except (TypeError, ValueError):
                content_length = 0
            report("Downloading update package…", 0)
            with archive_path.open("wb") as output:
                while True:
                    chunk = response.read(1024 * 1024)
                    if not chunk:
                        break
                    total += len(chunk)
                    if total > MAX_DOWNLOAD_BYTES:
                        raise RuntimeError("Update package exceeds the 300 MB download limit.")
                    digest.update(chunk)
                    output.write(chunk)
                    if content_length > 0:
                        report(f"Downloading update… {total / (1024 * 1024):.1f} MB", min(88, 88 * total / content_length))
                    else:
                        report(f"Downloading update… {total / (1024 * 1024):.1f} MB", min(75, 4 + total / (5 * 1024 * 1024)))
    except Exception:
        shutil.rmtree(stage_root, ignore_errors=True)
        raise

    report("Verifying update checksum…", 90)
    if digest.hexdigest().lower() != manifest["sha256"]:
        shutil.rmtree(stage_root, ignore_errors=True)
        raise RuntimeError("Update package SHA-256 verification failed. Nothing was installed.")

    report("Checking and unpacking update files…", 93)
    try:
        with zipfile.ZipFile(archive_path, "r") as archive:
            infos = archive.infolist()
            if len(infos) > MAX_FILES:
                raise RuntimeError("Update package contains too many files.")
            unpacked_total = sum(info.file_size for info in infos)
            if unpacked_total > MAX_UNPACKED_BYTES:
                raise RuntimeError("Update package expands beyond the 700 MB safety limit.")
            for index, info in enumerate(infos, start=1):
                if infos:
                    report(f"Unpacking update files… ({index}/{len(infos)})", 93 + 6 * index / len(infos))
                destination = _safe_member_path(extract_root, info.filename)
                # Do not allow symbolic links in an update package.
                mode = (info.external_attr >> 16) & 0o170000
                if mode == 0o120000:
                    raise RuntimeError("Symbolic links are not permitted in update packages.")
                if info.is_dir():
                    destination.mkdir(parents=True, exist_ok=True)
                    continue
                destination.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(info, "r") as source, destination.open("wb") as output:
                    shutil.copyfileobj(source, output)
    except Exception:
        shutil.rmtree(stage_root, ignore_errors=True)
        raise

    # Accept either a ZIP containing app files at its root or a single enclosing folder.
    payload = extract_root
    if not (payload / "shorts_studio.py").is_file():
        candidates = [p for p in payload.iterdir() if p.is_dir() and (p / "shorts_studio.py").is_file()]
        if len(candidates) == 1:
            payload = candidates[0]
        else:
            shutil.rmtree(stage_root, ignore_errors=True)
            raise RuntimeError("Update package does not contain shorts_studio.py at its root.")
    report("Update downloaded and verified.", 100)
    return payload
