@echo off
setlocal
cd /d "%~dp0"
echo Installing Python requirements for ByteTalk Shorts Studio...
py -m pip install --upgrade pip
if errorlevel 1 goto fail
py -m pip install -r requirements.txt
if errorlevel 1 goto fail
echo.
echo Install finished. You can now double-click run_app.bat.
pause
exit /b 0
:fail
echo.
echo Installation failed. Make sure Python 3.10 or newer is installed and added to PATH.
pause
exit /b 1
