from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import time
import threading
import tkinter as tk
from tkinter import ttk
from pathlib import Path, PurePosixPath

PROTECTED_TOP_LEVEL = {
    "workspace", "finished", "minecraft_backgrounds", ".updates",
    ".venv", "venv", "__pycache__", "$recycle.bin",
}
PROTECTED_FILES = {"update_config.json"}


def wait_for_parent(pid: int) -> None:
    if pid <= 0:
        return
    if os.name == "nt":
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(0x00100000, False, pid)  # SYNCHRONIZE
            if handle:
                try:
                    kernel32.WaitForSingleObject(handle, 120_000)
                finally:
                    kernel32.CloseHandle(handle)
                return
        except Exception:
            pass
    # Fallback for platforms where direct process waiting is unavailable.
    deadline = time.time() + 120
    while time.time() < deadline:
        try:
            os.kill(pid, 0)
        except OSError:
            return
        time.sleep(0.25)


def safe_relative(name: str) -> Path | None:
    path = PurePosixPath(name.replace("\\", "/"))
    if path.is_absolute() or not path.parts or any(part in ("", ".", "..") for part in path.parts):
        return None
    if len(path.parts) >= 1 and path.parts[0].lower() in PROTECTED_TOP_LEVEL:
        return None
    if len(path.parts) == 1 and path.parts[0].lower() in PROTECTED_FILES:
        return None
    if ":" in path.parts[0] or "\x00" in name:
        return None
    return Path(*path.parts)


def install_payload(app_dir: Path, payload_dir: Path, parent_pid: int, progress_callback=None) -> None:
    app_dir = app_dir.resolve()
    payload_dir = payload_dir.resolve()
    updates_root = (app_dir / ".updates").resolve()
    try:
        payload_dir.relative_to(updates_root)
    except ValueError as exc:
        raise RuntimeError("Refusing to install a payload outside the app's .updates folder.") from exc
    if not (payload_dir / "shorts_studio.py").is_file():
        raise RuntimeError("Staged update is missing shorts_studio.py.")

    def report(message: str, percent: float) -> None:
        if progress_callback is not None:
            try:
                progress_callback(message, max(0.0, min(100.0, float(percent))))
            except Exception:
                pass

    report("Waiting for the app to close safely…", 0)
    wait_for_parent(parent_pid)
    report("Preparing to replace app files…", 5)

    stamp = time.strftime("%Y%m%d_%H%M%S")
    backup_root = updates_root / f"backup_{stamp}"
    backup_root.mkdir(parents=True, exist_ok=True)
    replaced: list[tuple[Path, Path | None]] = []
    source_files = [source for source in payload_dir.rglob("*") if source.is_file()]

    try:
        for index, source in enumerate(source_files, start=1):
            relative = safe_relative(source.relative_to(payload_dir).as_posix())
            if relative is None:
                continue
            destination = (app_dir / relative).resolve()
            try:
                destination.relative_to(app_dir)
            except ValueError:
                raise RuntimeError(f"Refusing to overwrite a path outside the app folder: {relative}")

            destination.parent.mkdir(parents=True, exist_ok=True)
            backup = None
            if destination.exists():
                backup = backup_root / relative
                backup.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(destination, backup)
            replaced.append((destination, backup))
            temp_destination = destination.with_name(destination.name + ".update_tmp")
            shutil.copy2(source, temp_destination)
            os.replace(temp_destination, destination)
            report(f"Installing app files… ({index}/{len(source_files)})", 5 + 85 * index / max(1, len(source_files)))
        report("Update installed. Restarting ByteTalk Shorts Studio…", 98)
    except Exception:
        print("Update failed; restoring previously installed files...")
        for destination, backup in reversed(replaced):
            try:
                if backup and backup.exists():
                    shutil.copy2(backup, destination)
                elif destination.exists():
                    destination.unlink()
            except OSError:
                pass
        raise

    launcher = app_dir / "run_app.bat"
    if os.name == "nt" and launcher.exists():
        subprocess.Popen(
            ["cmd.exe", "/c", "start", "", "run_app.bat"],
            cwd=str(app_dir),
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    else:
        subprocess.Popen([sys.executable, str(app_dir / "shorts_studio.py")], cwd=str(app_dir))
    report("Update complete. The app is restarting…", 100)


def main() -> int:
    parser = argparse.ArgumentParser(description="Installs a verified staged ByteTalk Shorts Studio update.")
    parser.add_argument("--app-dir", required=True)
    parser.add_argument("--payload-dir", required=True)
    parser.add_argument("--parent-pid", required=True, type=int)
    args = parser.parse_args()

    app_dir = Path(args.app_dir)
    payload_dir = Path(args.payload_dir)
    parent_pid = args.parent_pid

    root = tk.Tk()
    root.title("ByteTalk Shorts Studio Update")
    root.resizable(False, False)
    root.attributes("-topmost", True)
    root.protocol("WM_DELETE_WINDOW", lambda: None)
    frame = ttk.Frame(root, padding=14)
    frame.pack(fill="both", expand=True)
    ttk.Label(frame, text="Applying ByteTalk Shorts Studio update", font=("Segoe UI", 10, "bold")).pack(anchor="w")
    detail_var = tk.StringVar(value="Preparing update…", master=root)
    percent_var = tk.StringVar(value="0%", master=root)
    progress_var = tk.DoubleVar(value=0.0, master=root)
    ttk.Label(frame, textvariable=detail_var, wraplength=345).pack(anchor="w", pady=(8, 8))
    ttk.Progressbar(frame, maximum=100, variable=progress_var, length=345).pack(fill="x")
    ttk.Label(frame, textvariable=percent_var).pack(anchor="e", pady=(4, 0))
    close_button = ttk.Button(frame, text="Close", command=root.destroy)

    root.update_idletasks()
    width = max(380, root.winfo_reqwidth())
    height = max(145, root.winfo_reqheight())
    x = max(0, root.winfo_screenwidth() - width - 20)
    y = max(0, root.winfo_screenheight() - height - 70)
    root.geometry(f"{width}x{height}+{x}+{y}")

    def update_ui(message: str, percent: float):
        detail_var.set(message)
        progress_var.set(percent)
        percent_var.set(f"{percent:.0f}%")

    def worker():
        try:
            install_payload(app_dir, payload_dir, parent_pid, progress_callback=lambda m, p: root.after(0, lambda: update_ui(m, p)))
            root.after(900, root.destroy)
        except Exception as exc:
            def show_error(error=str(exc)):
                detail_var.set(f"Update failed: {error}. The previous app files were restored where possible.")
                close_button.pack(anchor="e", pady=(8, 0))
                # Relaunch the app after a failed update so the user is not stranded.
                try:
                    launcher = app_dir / "run_app.bat"
                    if os.name == "nt" and launcher.exists():
                        subprocess.Popen(["cmd.exe", "/c", "start", "", "run_app.bat"], cwd=str(app_dir), creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                except Exception:
                    pass
            root.after(0, show_error)

    threading.Thread(target=worker, daemon=True).start()
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
