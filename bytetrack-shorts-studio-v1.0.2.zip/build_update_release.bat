@echo off
setlocal
cd /d "%~dp0"
echo ===============================================
echo ByteTalk Shorts Studio - Build OTA Release
echo ===============================================
set /p VERSION=Release version (example 1.0.2): 
set /p OWNER=GitHub username or organization: 
set /p REPO=GitHub update repository name: 
if "%VERSION%"=="" goto bad
if "%OWNER%"=="" goto bad
if "%REPO%"=="" goto bad
py make_release.py %VERSION% %OWNER% %REPO%
echo.
pause
exit /b %errorlevel%
:bad
echo Please enter all three values.
pause
exit /b 1
