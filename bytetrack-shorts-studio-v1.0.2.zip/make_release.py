from __future__ import annotations

import hashlib
import json
import re
import sys
import zipfile
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
RELEASE_DIR = APP_DIR / "release_build"
# Only app files go into OTA packages; personal workspaces and local update config are excluded.
PACKAGE_FILES = [
    "shorts_studio.py",
    "app_update.py",
    "updater_helper.py",
    "run_app.bat",
    "install_requirements.bat",
    "requirements.txt",
    "README.txt",
    "make_release.py",
    "build_update_release.bat",
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    if len(sys.argv) != 4:
        print("Usage: py make_release.py VERSION GITHUB_OWNER REPOSITORY")
        print("Example: py make_release.py 1.0.2 myusername bytetrack-shorts-studio")
        return 2

    version, owner, repo = sys.argv[1:]
    if not re.fullmatch(r"\d+(?:\.\d+){1,3}", version):
        print("Version must look like 1.0.2 or 1.0.2.1")
        return 2
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", owner) or not re.fullmatch(r"[A-Za-z0-9_.-]+", repo):
        print("GitHub owner and repository may contain only letters, numbers, dots, underscores, and hyphens.")
        return 2

    missing = [name for name in PACKAGE_FILES if not (APP_DIR / name).is_file()]
    if missing:
        print("Missing app files: " + ", ".join(missing))
        return 1

    RELEASE_DIR.mkdir(exist_ok=True)
    archive_name = f"bytetrack-shorts-studio-v{version}.zip"
    archive_path = RELEASE_DIR / archive_name
    with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=8) as archive:
        for name in PACKAGE_FILES:
            archive.write(APP_DIR / name, arcname=name)

    download_url = f"https://github.com/{owner}/{repo}/releases/download/v{version}/{archive_name}"
    manifest = {
        "version": version,
        "download_url": download_url,
        "sha256": sha256(archive_path),
        "changelog": "Replace this sentence with a summary of the UI changes, fixes, and improvements in this release."
    }
    manifest_path = RELEASE_DIR / "latest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")

    print("Release package created:")
    print(f"  ZIP:      {archive_path}")
    print(f"  Manifest: {manifest_path}")
    print("\nUpload the ZIP as an asset on a GitHub Release tagged:")
    print(f"  v{version}")
    print("Then copy release_build/latest.json to the root of the public repository's main branch.")
    print("Configure the app's feed URL as:")
    print(f"  https://raw.githubusercontent.com/{owner}/{repo}/main/latest.json")
    print("\nEdit the changelog field in latest.json before publishing if you want different release notes.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
