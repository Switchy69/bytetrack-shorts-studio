from __future__ import annotations

import asyncio
import html
import os
import queue
import random
import re
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path
from tkinter import Tk, Toplevel, StringVar, BooleanVar, DoubleVar, END, filedialog, messagebox, simpledialog
from tkinter import ttk

from app_update import (
    APP_VERSION, fetch_manifest, is_configured_manifest_url, is_newer,
    load_config as load_update_config, save_config as save_update_config,
    download_and_stage,
)

try:
    import yt_dlp
except ImportError:
    yt_dlp = None

APP_DIR = Path(__file__).resolve().parent
WORK_DIR = APP_DIR / "workspace"
SOURCE_DIR = WORK_DIR / "sources"
TRANSCRIPT_DIR = WORK_DIR / "transcripts"
SCRIPT_DIR = WORK_DIR / "scripts"
OUTPUT_DIR = APP_DIR / "finished"
DEFAULT_BG_DIR = APP_DIR / "minecraft_backgrounds"
HISTORY_FILE = WORK_DIR / "processed_history.txt"
CHANNEL_DEFAULT = "https://www.youtube.com/@ByteTalkYT-l8s/shorts"
VIDEO_EXTS = {".mp4", ".mkv", ".webm", ".mov", ".m4v"}
VOICE = "en-US-GuyNeural"

for folder in (SOURCE_DIR, TRANSCRIPT_DIR, SCRIPT_DIR, OUTPUT_DIR, DEFAULT_BG_DIR):
    folder.mkdir(parents=True, exist_ok=True)


def log_emit(log_queue: queue.Queue, text: str) -> None:
    log_queue.put(text)


def read_history() -> set[str]:
    if not HISTORY_FILE.exists():
        return set()
    return {line.strip() for line in HISTORY_FILE.read_text(encoding="utf-8").splitlines() if line.strip()}


def write_history(video_id: str) -> None:
    WORK_DIR.mkdir(parents=True, exist_ok=True)
    with HISTORY_FILE.open("a", encoding="utf-8") as f:
        f.write(video_id + "\n")


def ffmpeg_path() -> str:
    """Find FFmpeg, preferring the bundled imageio-ffmpeg executable."""
    found = shutil.which("ffmpeg")
    if found:
        return found
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception as exc:
        raise RuntimeError("FFmpeg not found. Install the app requirements, then restart the app.") from exc


def clean_name(text: str, max_len: int = 90) -> str:
    text = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", text)
    text = re.sub(r"\s+", " ", text).strip(" ._")
    return (text or "short")[:max_len]


def find_existing_media(video_id: str) -> Path | None:
    for p in SOURCE_DIR.glob(video_id + ".*"):
        if p.suffix.lower() in VIDEO_EXTS and p.is_file() and p.stat().st_size > 0:
            return p
    return None


def scan_channel(url: str, scan_limit: int, log_queue: queue.Queue) -> list[dict]:
    if yt_dlp is None:
        raise RuntimeError("yt-dlp is missing. Run install_requirements.bat first.")
    log_emit(log_queue, f"Scanning Shorts page: {url}")
    options = {
        "extract_flat": "in_playlist",
        "skip_download": True,
        "playlistend": max(5, int(scan_limit)),
        "quiet": True,
        "no_warnings": False,
        "ignoreerrors": True,
    }
    with yt_dlp.YoutubeDL(options) as ydl:
        info = ydl.extract_info(url, download=False)
    if not info:
        raise RuntimeError("YouTube did not return channel data. Check the URL or try again later.")
    entries = info.get("entries")
    if entries is None:
        raise RuntimeError("The URL did not return a Shorts playlist. Use the channel's /shorts URL.")
    videos = [entry for entry in entries if entry and entry.get("id")]
    log_emit(log_queue, f"Found {len(videos)} entries in the recent Shorts scan.")
    return videos


def download_source(video: dict, log_queue: queue.Queue) -> Path:
    video_id = video["id"]
    existing = find_existing_media(video_id)
    if existing:
        log_emit(log_queue, f"Using existing source file: {existing.name}")
        return existing

    title = video.get("title") or video_id
    url = video.get("webpage_url") or video.get("url")
    if not isinstance(url, str) or not url.startswith("http"):
        url = f"https://www.youtube.com/watch?v={video_id}"

    ffmpeg = ffmpeg_path()
    opts = {
        "format": "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best",
        "outtmpl": str(SOURCE_DIR / "%(id)s.%(ext)s"),
        "windowsfilenames": True,
        "noplaylist": True,
        "quiet": True,
        "no_warnings": False,
        "retries": 3,
        "fragment_retries": 3,
        "overwrites": False,
        "writesubtitles": True,
        "writeautomaticsub": True,
        "subtitleslangs": ["en.*", "en"],
        "subtitlesformat": "vtt/best",
        "ffmpeg_location": ffmpeg,
    }
    log_emit(log_queue, f"Downloading source: {title}")
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=True)
    source = find_existing_media(video_id)
    if source is None:
        # Fallback for extractors that append a format/metadata suffix.
        candidates = [p for p in SOURCE_DIR.glob(video_id + "*") if p.suffix.lower() in VIDEO_EXTS and p.is_file()]
        if candidates:
            source = max(candidates, key=lambda p: p.stat().st_size)
    if source is None:
        raise RuntimeError(f"Download returned but no video file was found for {video_id}.")
    return source


def strip_vtt(path: Path) -> str:
    raw = path.read_text(encoding="utf-8", errors="ignore")
    lines = []
    for line in raw.replace("\ufeff", "").splitlines():
        line = line.strip()
        if not line or line == "WEBVTT" or line.startswith(("NOTE", "Kind:", "Language:")):
            continue
        if "-->" in line or re.fullmatch(r"\d+", line):
            continue
        line = re.sub(r"<[^>]+>", "", line)
        line = html.unescape(line)
        line = re.sub(r"\s+", " ", line).strip()
        if line and (not lines or line != lines[-1]):
            lines.append(line)
    text = " ".join(lines)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def transcript_from_sidecar(video_id: str) -> str:
    files = list(SOURCE_DIR.glob(video_id + "*.vtt")) + list(SOURCE_DIR.glob(video_id + "*.srt"))
    for path in files:
        text = strip_vtt(path)
        if len(text.split()) >= 5:
            return text
    return ""


def transcribe_with_whisper(media_path: Path, log_queue: queue.Queue) -> str:
    try:
        from faster_whisper import WhisperModel
    except ImportError as exc:
        raise RuntimeError(
            "No usable YouTube captions were found and faster-whisper is not installed. "
            "Run install_requirements.bat, then try again."
        ) from exc
    log_emit(log_queue, "No usable captions found. Transcribing audio locally (first run may download a model).")
    model = WhisperModel("base", device="cpu", compute_type="int8")
    segments, _info = model.transcribe(str(media_path), beam_size=3, vad_filter=True)
    pieces = [segment.text.strip() for segment in segments if segment.text.strip()]
    text = re.sub(r"\s+", " ", " ".join(pieces)).strip()
    if len(text.split()) < 5:
        raise RuntimeError("Transcription returned too little speech to create a voiceover.")
    return text


def get_transcript(video_id: str, media_path: Path, log_queue: queue.Queue) -> str:
    transcript_path = TRANSCRIPT_DIR / f"{video_id}.txt"
    if transcript_path.exists():
        saved = transcript_path.read_text(encoding="utf-8").strip()
        if len(saved.split()) >= 5:
            return saved
    text = transcript_from_sidecar(video_id)
    if len(text.split()) < 5:
        text = transcribe_with_whisper(media_path, log_queue)
    transcript_path.write_text(text + "\n", encoding="utf-8")
    return text


def create_tts_and_captions(text: str, audio_path: Path, srt_path: Path, log_queue: queue.Queue) -> None:
    try:
        import edge_tts
    except ImportError as exc:
        raise RuntimeError("edge-tts is missing. Run install_requirements.bat and restart the app.") from exc

    # Keep the narration manageable for Shorts. The transcript/script is saved separately.
    if len(text) > 9000:
        text = text[:9000].rsplit(" ", 1)[0]
    log_emit(log_queue, f"Generating AI voice ({VOICE}) and timed captions...")

    async def generate() -> list[tuple[float, float, str]]:
        communicate = edge_tts.Communicate(text, VOICE, rate="+5%")
        words: list[tuple[float, float, str]] = []
        with audio_path.open("wb") as audio_file:
            async for chunk in communicate.stream():
                if chunk.get("type") == "audio":
                    audio_file.write(chunk["data"])
                elif chunk.get("type") == "WordBoundary":
                    word = str(chunk.get("text", "")).strip()
                    if word:
                        start = float(chunk.get("offset", 0)) / 10_000_000
                        duration = float(chunk.get("duration", 0)) / 10_000_000
                        words.append((start, max(start + duration, start + 0.12), word))
        return words

    words = asyncio.run(generate())
    if not audio_path.exists() or audio_path.stat().st_size < 1000:
        raise RuntimeError("AI voice generation did not return an audio file.")

    # Group 4-6 word boundaries into high-contrast, easy-to-read caption cards.
    groups: list[list[tuple[float, float, str]]] = []
    current: list[tuple[float, float, str]] = []
    for word in words:
        current.append(word)
        token = word[2]
        if len(current) >= 5 or (len(current) >= 3 and re.search(r"[.!?,]$", token)):
            groups.append(current)
            current = []
    if current:
        groups.append(current)

    def timestamp(seconds: float) -> str:
        total_ms = max(0, int(seconds * 1000))
        hours, remainder = divmod(total_ms, 3_600_000)
        minutes, remainder = divmod(remainder, 60_000)
        seconds_i, millis = divmod(remainder, 1000)
        return f"{hours:02}:{minutes:02}:{seconds_i:02},{millis:03}"

    srt_lines = []
    for index, group in enumerate(groups, start=1):
        start = group[0][0]
        end = max(group[-1][1], start + 0.25)
        caption = " ".join(item[2] for item in group).upper()
        caption = caption.replace("&", "and")
        srt_lines += [str(index), f"{timestamp(start)} --> {timestamp(end)}", caption, ""]
    srt_path.write_text("\n".join(srt_lines), encoding="utf-8")


def escape_filter_path(path: Path) -> str:
    # FFmpeg filter arguments use ':' as a separator even on Windows paths.
    value = path.resolve().as_posix()
    value = value.replace("'", r"\'").replace(":", r"\:").replace(",", r"\,")
    return value


def build_final_video(source: Path, background: Path, audio: Path, srt: Path, output_path: Path, log_queue: queue.Queue) -> None:
    ffmpeg = ffmpeg_path()
    # Approximate the circled top panel from the supplied example: crop the upper
    # central region of the Short, then center it over a 9:16 Minecraft background.
    sub_path = escape_filter_path(srt)
    filters = (
        "[0:v]scale=1080:1920:force_original_aspect_ratio=increase,"
        "crop=1080:1920,setsar=1[bg];"
        "[1:v]crop=w=trunc(iw*0.70/2)*2:h=trunc(ih*0.30/2)*2:"
        "x=iw*0.08:y=ih*0.04,scale=820:-2[panel];"
        "[bg][panel]overlay=(W-w)/2:90:eof_action=repeat[base];"
        f"[base]subtitles='{sub_path}':force_style='FontName=Arial,FontSize=58,"
        "Bold=1,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,"
        "BorderStyle=1,Outline=5,Shadow=1,Alignment=2,MarginV=260'[v]"
    )
    cmd = [
        ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
        "-stream_loop", "-1", "-i", str(background),
        "-i", str(source), "-i", str(audio),
        "-filter_complex", filters,
        "-map", "[v]", "-map", "2:a:0",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
        "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
        "-shortest", "-movflags", "+faststart", str(output_path)
    ]
    log_emit(log_queue, f"Rendering finished Short: {output_path.name}")
    completed = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if completed.returncode != 0:
        err = completed.stderr[-3500:] if completed.stderr else "Unknown FFmpeg error"
        raise RuntimeError("FFmpeg could not render the final Short.\n" + err)
    if not output_path.exists() or output_path.stat().st_size < 100_000:
        raise RuntimeError("FFmpeg finished but the output file is missing or unexpectedly small.")


def process_video(video: dict, bg_dir: Path, log_queue: queue.Queue) -> None:
    video_id = video["id"]
    title = clean_name(video.get("title") or video_id)
    source = download_source(video, log_queue)
    transcript = get_transcript(video_id, source, log_queue)
    script_path = SCRIPT_DIR / f"{video_id}_voice_script.txt"
    script_path.write_text(transcript + "\n", encoding="utf-8")

    audio_path = WORK_DIR / f"{video_id}_voice.mp3"
    srt_path = WORK_DIR / f"{video_id}_captions.srt"
    output_path = OUTPUT_DIR / f"{video_id}_{title}.mp4"
    create_tts_and_captions(transcript, audio_path, srt_path, log_queue)

    backgrounds = [p for p in bg_dir.iterdir() if p.is_file() and p.suffix.lower() in VIDEO_EXTS]
    if not backgrounds:
        raise RuntimeError(
            f"No Minecraft background videos were found in {bg_dir}. Add MP4/MKV/WebM gameplay clips and try again."
        )
    background = random.choice(backgrounds)
    log_emit(log_queue, f"Minecraft background selected: {background.name}")
    build_final_video(source, background, audio_path, srt_path, output_path, log_queue)
    write_history(video_id)
    log_emit(log_queue, f"DONE: {output_path}")
    log_emit(log_queue, f"Transcript: {TRANSCRIPT_DIR / (video_id + '.txt')}")
    log_emit(log_queue, f"Voice script: {script_path}")


class ShortsStudio:
    def __init__(self, root: Tk):
        self.root = root
        self.root.title(f"ByteTalk Shorts Studio v{APP_VERSION}")
        self.root.geometry("880x650")
        self.root.minsize(760, 560)
        self.log_queue: queue.Queue = queue.Queue()
        self.busy = False
        self.auto_enabled = False
        self.auto_after_id = None
        self.update_checking = False
        self.update_requested = False
        self.update_download_started = False
        self.update_available_manifest = None
        self.update_popup = None
        self.update_popup_title = None
        self.update_popup_detail = None
        self.update_progress_var = DoubleVar(value=0.0, master=self.root)
        self.update_percent_var = StringVar(value="0%", master=self.root)
        self.update_poll_after_id = None

        self.channel_var = StringVar(value=CHANNEL_DEFAULT)
        self.bg_var = StringVar(value=str(DEFAULT_BG_DIR))
        self.out_var = StringVar(value=str(OUTPUT_DIR))
        self.scan_var = StringVar(value="100")
        self.new_var = StringVar(value="5")
        self.interval_var = StringVar(value="60")
        self.auto_var = BooleanVar(value=False)
        self.status_var = StringVar(value="Ready. Add Minecraft background videos, then click Check now.")

        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure("Title.TLabel", font=("Segoe UI", 16, "bold"))
        style.configure("Hint.TLabel", font=("Segoe UI", 9))
        style.configure("Run.TButton", font=("Segoe UI", 10, "bold"), padding=7)

        self._build_ui()
        self.root.after(180, self._drain_logs)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self.root.after(1200, self._startup_update_check)
        self.update_poll_after_id = self.root.after(30_000, self._periodic_update_check)

    def _build_ui(self):
        outer = ttk.Frame(self.root, padding=14)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text=f"ByteTalk Shorts Studio  ·  v{APP_VERSION}", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            outer,
            text="Checks the channel's Shorts tab, transcribes speech, generates AI narration + captions, and renders a vertical edit.",
            style="Hint.TLabel", wraplength=820
        ).pack(anchor="w", pady=(3, 12))

        form = ttk.Frame(outer)
        form.pack(fill="x")
        form.columnconfigure(1, weight=1)

        def add_row(row, label, variable, browse=None):
            ttk.Label(form, text=label).grid(row=row, column=0, sticky="w", padx=(0, 10), pady=4)
            ttk.Entry(form, textvariable=variable).grid(row=row, column=1, sticky="ew", pady=4)
            if browse:
                ttk.Button(form, text="Browse...", command=browse).grid(row=row, column=2, padx=(8, 0), pady=4)

        add_row(0, "Channel Shorts URL", self.channel_var)
        add_row(1, "Minecraft backgrounds", self.bg_var, self._choose_bg)
        add_row(2, "Finished videos folder", self.out_var, self._choose_out)

        settings = ttk.Frame(outer)
        settings.pack(fill="x", pady=(8, 4))
        ttk.Label(settings, text="Scan recent entries:").pack(side="left")
        ttk.Entry(settings, textvariable=self.scan_var, width=7).pack(side="left", padx=(6, 14))
        ttk.Label(settings, text="New Shorts per check:").pack(side="left")
        ttk.Entry(settings, textvariable=self.new_var, width=5).pack(side="left", padx=(6, 14))
        ttk.Label(settings, text="Auto-check every (minutes):").pack(side="left")
        ttk.Entry(settings, textvariable=self.interval_var, width=6).pack(side="left", padx=(6, 0))

        buttons = ttk.Frame(outer)
        buttons.pack(fill="x", pady=(8, 8))
        self.run_button = ttk.Button(buttons, text="Check channel now", style="Run.TButton", command=self.start_check)
        self.run_button.pack(side="left")
        self.auto_button = ttk.Button(buttons, text="Start auto-check", command=self.toggle_auto)
        self.auto_button.pack(side="left", padx=(8, 0))
        ttk.Button(buttons, text="Open finished folder", command=self._open_output).pack(side="left", padx=(8, 0))
        ttk.Button(buttons, text="Open workspace", command=self._open_workspace).pack(side="left", padx=(8, 0))
        self.update_button = ttk.Button(buttons, text="Check for updates", command=self.check_for_updates)
        self.update_button.pack(side="left", padx=(8, 0))
        ttk.Button(buttons, text="Set update feed", command=self.configure_update_feed).pack(side="left", padx=(8, 0))

        ttk.Label(outer, textvariable=self.status_var, wraplength=820).pack(anchor="w", pady=(0, 6))
        self.log = __import__("tkinter").Text(outer, height=18, wrap="word", bg="#10131a", fg="#e9edf5", insertbackground="white", relief="flat", font=("Consolas", 9))
        self.log.pack(fill="both", expand=True)
        self.log.configure(state="disabled")
        ttk.Label(
            outer,
            text="Notes: This app runs locally while open. Keep permitted source material and your own/licensed Minecraft gameplay in the background folder. First-time transcription may download a Whisper model.",
            style="Hint.TLabel", wraplength=820
        ).pack(anchor="w", pady=(8, 0))

    def _choose_bg(self):
        path = filedialog.askdirectory(title="Choose folder with Minecraft gameplay videos", initialdir=self.bg_var.get())
        if path:
            self.bg_var.set(path)

    def _choose_out(self):
        path = filedialog.askdirectory(title="Choose finished videos folder", initialdir=self.out_var.get())
        if path:
            self.out_var.set(path)

    def _open_folder(self, path: Path):
        path.mkdir(parents=True, exist_ok=True)
        try:
            if os.name == "nt":
                os.startfile(str(path))
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(path)])
            else:
                subprocess.Popen(["xdg-open", str(path)])
        except Exception as exc:
            messagebox.showerror("Open folder", str(exc))

    def _open_output(self):
        self._open_folder(Path(self.out_var.get()).expanduser())

    def _open_workspace(self):
        self._open_folder(WORK_DIR)

    def _startup_update_check(self):
        """Silently check at startup when a real HTTPS feed has been configured."""
        try:
            config = load_update_config(APP_DIR)
            if config.get("auto_check_on_start", True):
                url = str(config.get("manifest_url", "")).strip()
                if is_configured_manifest_url(url):
                    self.check_for_updates(silent=True)
                else:
                    self._write_log(
                        "Updater ready but not connected to a release feed yet. "
                        "Use Set update feed after publishing a GitHub release feed."
                    )
        except Exception as exc:
            self._write_log(f"Could not initialize update check: {exc}")

    def _periodic_update_check(self):
        """Poll the configured GitHub manifest every 30 seconds while open."""
        self.update_poll_after_id = None
        try:
            config = load_update_config(APP_DIR)
            url = str(config.get("manifest_url", "")).strip()
            if (not self.update_requested and not self.update_checking
                    and is_configured_manifest_url(url)):
                self.check_for_updates(silent=True)
        except Exception as exc:
            self._write_log(f"Scheduled update check could not start: {exc}")
        if self.root.winfo_exists():
            self.update_poll_after_id = self.root.after(30_000, self._periodic_update_check)

    def configure_update_feed(self):
        config = load_update_config(APP_DIR)
        current_url = str(config.get("manifest_url", ""))
        url = simpledialog.askstring(
            "Configure over-the-air updates",
            "Paste the HTTPS URL for your hosted latest.json update manifest.\n\n"
            "Example: https://raw.githubusercontent.com/Switchy69/bytetrack-shorts-studio/main/latest.json\n\n"
            "Leave blank to disable automatic update checks.",
            initialvalue=current_url,
            parent=self.root,
        )
        if url is None:
            return
        url = url.strip()
        if url and not url.startswith("https://"):
            messagebox.showerror("Invalid update feed", "The update feed must use an HTTPS URL.", parent=self.root)
            return
        save_update_config(APP_DIR, {"manifest_url": url, "auto_check_on_start": True})
        self._write_log("Update feed settings saved.")
        if is_configured_manifest_url(url):
            messagebox.showinfo("Update feed saved", "Feed saved. Checking for updates now.", parent=self.root)
            self.check_for_updates(silent=False)
        else:
            messagebox.showinfo(
                "Updates not connected",
                "The update feed is not configured yet. Publish latest.json and a matching GitHub Release first.",
                parent=self.root,
            )

    def _ensure_update_popup(self):
        if self.update_popup is not None:
            try:
                if self.update_popup.winfo_exists():
                    return
            except Exception:
                pass
        popup = Toplevel(self.root)
        popup.title("ByteTalk Shorts Studio Update")
        popup.resizable(False, False)
        popup.attributes("-topmost", True)
        popup.protocol("WM_DELETE_WINDOW", lambda: None)
        frame = ttk.Frame(popup, padding=12)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, textvariable=self.update_popup_title, font=("Segoe UI", 10, "bold")).pack(anchor="w")
        ttk.Label(frame, textvariable=self.update_popup_detail, wraplength=350).pack(anchor="w", pady=(5, 8))
        ttk.Progressbar(
            frame, maximum=100, variable=self.update_progress_var, length=350, mode="determinate"
        ).pack(fill="x")
        ttk.Label(frame, textvariable=self.update_percent_var).pack(anchor="e", pady=(3, 0))
        popup.update_idletasks()
        width = max(380, popup.winfo_reqwidth())
        height = max(140, popup.winfo_reqheight())
        x = max(0, popup.winfo_screenwidth() - width - 20)
        y = max(0, popup.winfo_screenheight() - height - 70)
        popup.geometry(f"{width}x{height}+{x}+{y}")
        self.update_popup = popup

    def _show_update_popup(self, detail: str, percent: float | None = None, title: str = "ByteTalk Shorts Studio is updating"):
        if self.update_popup_title is None:
            self.update_popup_title = StringVar(value=title, master=self.root)
            self.update_popup_detail = StringVar(value=detail, master=self.root)
        self._ensure_update_popup()
        self.update_popup_title.set(title)
        self.update_popup_detail.set(detail)
        if percent is not None:
            numeric = max(0.0, min(100.0, float(percent)))
            self.update_progress_var.set(numeric)
            self.update_percent_var.set(f"{numeric:.0f}%")
        try:
            self.update_popup.deiconify()
            self.update_popup.lift()
        except Exception:
            pass

    def _close_update_popup(self):
        popup, self.update_popup = self.update_popup, None
        if popup is not None:
            try:
                popup.destroy()
            except Exception:
                pass

    def check_for_updates(self, silent=False):
        if self.update_checking or self.update_requested:
            return
        config = load_update_config(APP_DIR)
        manifest_url = str(config.get("manifest_url", "")).strip()
        if not is_configured_manifest_url(manifest_url):
            self._write_log("Over-the-air updates are not connected yet; set a hosted latest.json URL first.")
            if not silent:
                messagebox.showinfo(
                    "Update feed not configured",
                    "This app includes an updater, but it needs a hosted HTTPS latest.json manifest before it can receive updates.\n\n"
                    "Use Set update feed after you publish a release feed. See README.txt for setup instructions.",
                    parent=self.root,
                )
            return

        self.update_checking = True
        self.update_button.configure(state="disabled")
        if not silent and not self.busy:
            self.status_var.set("Checking for app updates...")
        self._write_log(f"Checking for app updates (current version {APP_VERSION})...")

        def worker():
            try:
                manifest = fetch_manifest(manifest_url)
            except Exception as exc:
                self.root.after(0, lambda error=str(exc): self._update_check_failed(error, silent))
                return
            self.root.after(0, lambda item=manifest: self._handle_update_manifest(item, silent))

        threading.Thread(target=worker, daemon=True).start()

    def _update_check_failed(self, error, silent):
        self.update_checking = False
        self.update_button.configure(state="normal")
        self._write_log(f"Update check failed: {error}")
        if not self.busy:
            self.status_var.set("Update check failed. The app itself can still be used.")
        if not silent:
            messagebox.showerror("Update check failed", str(error), parent=self.root)

    def _handle_update_manifest(self, manifest, silent):
        self.update_checking = False
        self.update_button.configure(state="normal")
        remote_version = str(manifest.get("version", ""))
        try:
            available = is_newer(remote_version, APP_VERSION)
        except Exception as exc:
            self._update_check_failed(str(exc), silent)
            return

        if not available:
            if not self.busy and not self.update_requested:
                self.status_var.set(f"App is up to date · v{APP_VERSION}")
            if not silent:
                messagebox.showinfo("No update available", f"You're running v{APP_VERSION}. Latest release is v{remote_version}.", parent=self.root)
            return

        self.update_available_manifest = manifest
        self.update_requested = True
        self.update_download_started = False
        changelog = str(manifest.get("changelog", "General improvements and fixes."))
        self._write_log(f"Update available: v{APP_VERSION} → v{remote_version}")
        self._write_log(f"Release notes: {changelog}")
        self.run_button.configure(state="disabled")
        self.update_button.configure(state="disabled")
        if self.auto_after_id is not None:
            try:
                self.root.after_cancel(self.auto_after_id)
            except Exception:
                pass
            self.auto_after_id = None
        self.auto_enabled = False
        self.auto_var.set(False)
        self.auto_button.configure(text="Start auto-check", state="disabled")

        if self.busy:
            detail = f"Version {remote_version} is ready. Finishing the current Short, then pausing processing…"
            self.status_var.set("Update waiting for the current Short to finish…")
            self._show_update_popup(detail, 0, f"Update available · v{remote_version}")
            self._write_log("Update detected while processing. New Shorts are paused; the current Short will finish safely.")
        else:
            self._show_update_popup(f"Downloading v{remote_version}. New processing is paused until the update completes.\n{changelog}", 0, f"Update available · v{remote_version}")
            self._download_update(manifest)

    def _download_update(self, manifest):
        if self.update_download_started:
            return
        self.update_download_started = True
        self.update_checking = True
        self.update_button.configure(state="disabled")
        version = str(manifest.get("version", "unknown"))
        self.status_var.set(f"Downloading update v{version}...")
        self._write_log(f"Downloading and verifying update package v{version}...")
        self._show_update_popup("Preparing secure download…", 0, f"Downloading update · v{version}")

        def progress_callback(status: str, percent: float):
            self.root.after(0, lambda s=status, p=percent: self._show_update_popup(s, p, f"Downloading update · v{version}"))

        def worker():
            try:
                payload = download_and_stage(manifest, APP_DIR, progress_callback=progress_callback)
            except Exception as exc:
                self.root.after(0, lambda error=str(exc): self._update_download_failed(error))
                return
            self.root.after(0, lambda p=payload, v=version: self._update_download_ready(p, v))

        threading.Thread(target=worker, daemon=True).start()

    def _update_download_failed(self, error):
        self.update_checking = False
        self.update_requested = False
        self.update_download_started = False
        self.update_available_manifest = None
        self.update_button.configure(state="normal")
        self.run_button.configure(state="normal")
        self.auto_button.configure(state="normal")
        self._close_update_popup()
        self._write_log(f"Update download failed: {error}")
        self.status_var.set("Update download failed. Current version is unchanged.")
        messagebox.showerror("Update download failed", str(error), parent=self.root)

    def _update_download_ready(self, payload, version):
        self.update_checking = False
        self._write_log(f"Update v{version} downloaded, checksum verified, and staged safely.")
        self.status_var.set(f"Installing update v{version} and restarting...")
        self._show_update_popup("Download and checksum verification complete. Applying update and restarting…", 100, f"Installing update · v{version}")
        self.root.after(350, lambda: self._launch_update_installer(payload, version))

    def _launch_update_installer(self, payload, version):
        helper = APP_DIR / "updater_helper.py"
        if not helper.is_file():
            self._update_download_failed("updater_helper.py was not found. Re-extract the full app package.")
            return
        command = [
            sys.executable, str(helper),
            "--app-dir", str(APP_DIR),
            "--payload-dir", str(payload),
            "--parent-pid", str(os.getpid()),
        ]
        try:
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
            subprocess.Popen(command, cwd=str(APP_DIR), creationflags=creationflags)
            self._write_log("Updater started. Closing the app so the verified update can be installed...")
            self.root.after(250, self.root.destroy)
        except Exception as exc:
            self._update_download_failed(f"Could not start updater: {exc}")

    def _write_log(self, text: str):
        self.log.configure(state="normal")
        self.log.insert(END, text + "\n")
        self.log.see(END)
        self.log.configure(state="disabled")

    def _drain_logs(self):
        try:
            while True:
                item = self.log_queue.get_nowait()
                if isinstance(item, tuple) and item and item[0] == "__status__":
                    self.status_var.set(item[1])
                elif isinstance(item, tuple) and item and item[0] == "__done__":
                    self.busy = False
                    if self.update_requested:
                        self.run_button.configure(state="disabled")
                        self.status_var.set("Processing paused. Downloading and applying the update...")
                        if self.update_available_manifest and not self.update_download_started:
                            self.root.after(250, lambda m=self.update_available_manifest: self._download_update(m))
                    else:
                        self.run_button.configure(state="normal")
                        self.auto_button.configure(state="normal")
                        if self.auto_enabled:
                            self.status_var.set("Auto-check active. Waiting for the next scan.")
                else:
                    self._write_log(str(item))
        except queue.Empty:
            pass
        self.root.after(180, self._drain_logs)

    def start_check(self):
        if self.update_requested:
            self._write_log("New processing is paused while the app update is being installed.")
            return
        if self.busy:
            return
        channel = self.channel_var.get().strip()
        if not channel.startswith("https://www.youtube.com/"):
            messagebox.showerror("Invalid channel URL", "Enter the full YouTube Shorts page URL.")
            return
        try:
            scan_limit = max(5, min(500, int(self.scan_var.get())))
            new_limit = max(1, min(20, int(self.new_var.get())))
        except ValueError:
            messagebox.showerror("Invalid settings", "Scan limit and new Shorts count must be numbers.")
            return
        bg_dir = Path(self.bg_var.get()).expanduser()
        out_dir = Path(self.out_var.get()).expanduser()
        if not bg_dir.exists() or not any(p.is_file() and p.suffix.lower() in VIDEO_EXTS for p in bg_dir.iterdir()):
            messagebox.showwarning(
                "Minecraft backgrounds needed",
                "Choose a folder containing MP4, MKV, WebM, MOV, or M4V Minecraft gameplay clips before processing."
            )
            return
        out_dir.mkdir(parents=True, exist_ok=True)
        global OUTPUT_DIR
        OUTPUT_DIR = out_dir
        self.busy = True
        self.run_button.configure(state="disabled")
        self.status_var.set("Checking the channel and processing new Shorts...")
        self._write_log("\n" + "=" * 68)

        def worker():
            try:
                recent = scan_channel(channel, scan_limit, self.log_queue)
                history = read_history()
                candidates = []
                seen = set()
                for item in recent:
                    vid = item.get("id")
                    if vid and vid not in history and vid not in seen:
                        seen.add(vid)
                        candidates.append(item)
                    if len(candidates) >= new_limit:
                        break
                if not candidates:
                    log_emit(self.log_queue, "No unprocessed Shorts found in the scanned entries.")
                else:
                    log_emit(self.log_queue, f"Queueing {len(candidates)} new Short(s).")
                successes = 0
                failures = 0
                for item in candidates:
                    if self.update_requested:
                        log_emit(self.log_queue, "Stopping the queue before the next Short so the app can update.")
                        break
                    try:
                        process_video(item, bg_dir, self.log_queue)
                        successes += 1
                    except Exception as exc:
                        failures += 1
                        log_emit(self.log_queue, f"FAILED {item.get('id', 'unknown')}: {exc}")
                    if self.update_requested:
                        log_emit(self.log_queue, "Current Short finished. Remaining Shorts paused for update.")
                        break
                self.log_queue.put(f"Check complete: {successes} finished, {failures} failed.")
                self.log_queue.put(("__status__", f"Done. {successes} finished, {failures} failed."))
            except Exception as exc:
                self.log_queue.put(f"ERROR: {exc}")
                self.log_queue.put(("__status__", "Check failed. See log for details."))
            finally:
                self.log_queue.put(("__done__", None))

        threading.Thread(target=worker, daemon=True).start()

    def toggle_auto(self):
        if not self.auto_enabled:
            try:
                interval = int(self.interval_var.get())
                if interval < 1:
                    raise ValueError
            except ValueError:
                messagebox.showerror("Invalid interval", "Auto-check interval must be a whole number of minutes (minimum 1).")
                return
            self.auto_enabled = True
            self.auto_var.set(True)
            self.auto_button.configure(text="Stop auto-check")
            self._write_log(f"Auto-check enabled. Will check every {interval} minute(s) while the app stays open.")
            if not self.busy:
                self.start_check()
            self._schedule_auto()
        else:
            self.auto_enabled = False
            self.auto_var.set(False)
            if self.auto_after_id is not None:
                self.root.after_cancel(self.auto_after_id)
                self.auto_after_id = None
            self.auto_button.configure(text="Start auto-check")
            self._write_log("Auto-check stopped.")

    def _schedule_auto(self):
        if not self.auto_enabled:
            return
        try:
            interval = max(1, int(self.interval_var.get()))
        except ValueError:
            interval = 60
        self.auto_after_id = self.root.after(interval * 60_000, self._auto_tick)

    def _auto_tick(self):
        self.auto_after_id = None
        if not self.auto_enabled:
            return
        if not self.busy:
            self.start_check()
        self._schedule_auto()

    def _on_close(self):
        if self.update_requested:
            messagebox.showinfo("Update in progress", "Please let the app finish its update before closing it.", parent=self.root)
            return
        if self.auto_enabled:
            if not messagebox.askyesno("Exit", "Auto-check will stop when the app closes. Exit anyway?"):
                return
        if self.update_poll_after_id is not None:
            try:
                self.root.after_cancel(self.update_poll_after_id)
            except Exception:
                pass
        self.root.destroy()

    # Called through queue drain after handling log/status payloads.


def main():
    load_update_config(APP_DIR)
    root = Tk()
    ShortsStudio(root)
    root.mainloop()


if __name__ == "__main__":
    main()
